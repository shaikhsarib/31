// config/db.js — In-memory SQLite (swap for PostgreSQL in production)
const initSqlJs = require('sql.js');
const crypto = require('crypto');

let db;

async function initDB() {
  const SQL = await initSqlJs();
  db = new SQL.Database();

  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      phone TEXT UNIQUE NOT NULL,
      username TEXT,
      ref_code TEXT UNIQUE NOT NULL,
      has_paid INTEGER DEFAULT 0,
      coins INTEGER DEFAULT 100 CHECK(coins >= 0),
      streak INTEGER DEFAULT 0,
      current_day INTEGER DEFAULT 1,
      tier_num INTEGER DEFAULT 1,
      spin_tickets INTEGER DEFAULT 0,
      referral_count INTEGER DEFAULT 0,
      device_fingerprint TEXT,
      registration_ip TEXT,
      is_banned INTEGER DEFAULT 0,
      ban_reason TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS otp_store (
      phone TEXT PRIMARY KEY,
      hash TEXT NOT NULL,
      attempts INTEGER DEFAULT 0,
      daily_count INTEGER DEFAULT 0,
      expires_at INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      details TEXT DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS task_completions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      task_key TEXT NOT NULL,
      day INTEGER NOT NULL,
      reward INTEGER NOT NULL,
      verification_method TEXT,
      completed_at TEXT DEFAULT (datetime('now')),
      UNIQUE(user_id, task_key, day)
    );

    CREATE TABLE IF NOT EXISTS coin_transactions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      amount INTEGER NOT NULL,
      type TEXT NOT NULL,
      description TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS referrals (
      id TEXT PRIMARY KEY,
      referrer_id TEXT NOT NULL,
      referred_id TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT (datetime('now')),
      UNIQUE(referrer_id, referred_id)
    );

    CREATE TABLE IF NOT EXISTS security_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      event TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS spin_records (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      spin_type TEXT,
      prize_coins INTEGER,
      prize_label TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  console.log('✅ Database initialized');
  return db;
}

function getDB() {
  if (!db) throw new Error('Database not initialized');
  return db;
}

// Simple query helpers
function query(sql, params = []) {
  const d = getDB();
  const stmt = d.prepare(sql);
  const rows = stmt.getAsObject ? [] : [];
  
  if (sql.trim().toUpperCase().startsWith('SELECT')) {
    const result = d.exec(sql, params);
    if (!result.length) return [];
    const cols = result[0].columns;
    return result[0].values.map(row => {
      const obj = {};
      cols.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  } else {
    d.run(sql, params);
    return { changes: d.getRowsModified() };
  }
}

module.exports = { initDB, getDB, query };
