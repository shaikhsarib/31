// services/spinService.js
// Server-side spin: browser CANNOT influence the outcome

const crypto = require('crypto');
const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

// In-memory spin lock (use Redis in prod)
const spinLocks = new Map();

const PRIZES = [
  { label: '30 coins',  coins: 30,  weight: 1    },
  { label: '1 coin',    coins: 1,   weight: 5000 },
  { label: '10 coins',  coins: 10,  weight: 200  },
  { label: '0 coins',   coins: 0,   weight: 1000 },
  { label: '5 coins',   coins: 5,   weight: 400  },
  { label: '15 coins',  coins: 15,  weight: 80   },
  { label: '20 coins',  coins: 20,  weight: 40   },
  { label: '25 coins',  coins: 25,  weight: 10   },
];

class SpinService {

  static pickPrize() {
    const totalWeight = PRIZES.reduce((s, p) => s + p.weight, 0);
    const rand = crypto.randomInt(1, totalWeight + 1);  // cryptographically secure
    let cumulative = 0;
    for (const prize of PRIZES) {
      cumulative += prize.weight;
      if (rand <= cumulative) return prize;
    }
    return PRIZES[1]; // fallback: 1 coin
  }

  static async spin(userId, spinType) {
    // Atomic lock — prevents double-spin exploit
    if (spinLocks.get(userId)) {
      throw new Error('SPIN_IN_PROGRESS');
    }
    spinLocks.set(userId, true);

    try {
      const users = query('SELECT * FROM users WHERE id = ?', [userId]);
      const u = users[0];
      if (!u) throw new Error('USER_NOT_FOUND');
      if (!u.has_paid) throw new Error('PAYMENT_REQUIRED');

      // Validate user has the right resource
      if (spinType === 'ticket') {
        if (u.spin_tickets < 1) throw new Error('NO_TICKETS');
        query('UPDATE users SET spin_tickets = spin_tickets - 1 WHERE id = ?', [userId]);
      } else {
        throw new Error('INVALID_SPIN_TYPE');
      }

      // Server picks outcome — browser gets the result, not the power to choose
      const prize = this.pickPrize();
      const prizeIndex = PRIZES.indexOf(prize);
      const sliceAngle = (2 * Math.PI) / PRIZES.length;

      // Tell the frontend EXACTLY which angle to animate to
      const targetAngle = prizeIndex * sliceAngle + sliceAngle / 2;
      const fullRotations = Math.PI * 2 * (8 + Math.floor(Math.random() * 3));
      const finalAngle = fullRotations + targetAngle;

      // Award coins in database
      if (prize.coins > 0) {
        query('UPDATE users SET coins = coins + ? WHERE id = ?', [prize.coins, userId]);
        query(
          'INSERT INTO coin_transactions (id, user_id, amount, type, description) VALUES (?, ?, ?, ?, ?)',
          [uuidv4(), userId, prize.coins, 'spin', `Spin win: ${prize.label}`]
        );
      }

      query(
        'INSERT INTO spin_records (id, user_id, spin_type, prize_coins, prize_label) VALUES (?, ?, ?, ?, ?)',
        [uuidv4(), userId, spinType, prize.coins, prize.label]
      );

      const updatedUser = query('SELECT coins FROM users WHERE id = ?', [userId]);

      return {
        prize,
        finalAngle,        // Frontend animates to THIS — cannot be manipulated
        newBalance: updatedUser[0].coins
      };

    } finally {
      spinLocks.delete(userId); // Always release lock
    }
  }
}

module.exports = SpinService;
