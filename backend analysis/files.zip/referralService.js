// services/referralService.js
const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class ReferralService {

  static async applyReferral(newUserId, newUserPhone, referralCode, newUserIP, newUserDevice) {
    // 1. Find referrer
    const referrers = query('SELECT * FROM users WHERE ref_code = ? AND has_paid = 1', [referralCode]);
    if (!referrers.length) throw new Error('REFERRAL_CODE_NOT_FOUND');
    const referrer = referrers[0];

    // 2. Can't refer yourself
    if (referrer.id === newUserId) {
      this.logFraud(newUserId, 'SELF_REFERRAL_ATTEMPT', { referralCode });
      throw new Error('SELF_REFERRAL_DETECTED');
    }

    // 3. Same device check
    if (newUserDevice && referrer.device_fingerprint === newUserDevice) {
      this.logFraud(newUserId, 'SAME_DEVICE_REFERRAL', { referrerId: referrer.id });
      throw new Error('SAME_DEVICE_REFERRAL_BLOCKED');
    }

    // 4. IP limit — max 2 referrals from same IP per referrer
    const sameIPCount = query(`
      SELECT COUNT(*) as cnt FROM referrals r
      JOIN users u ON r.referred_id = u.id
      WHERE r.referrer_id = ? AND u.registration_ip = ?
    `, [referrer.id, newUserIP]);
    if (sameIPCount[0]?.cnt >= 2) {
      this.logFraud(newUserId, 'SAME_IP_REFERRAL_LIMIT', { referrerId: referrer.id, ip: newUserIP });
      throw new Error('TOO_MANY_REFERRALS_FROM_SAME_IP');
    }

    // 5. Circular referral check
    const circular = query(
      'SELECT id FROM referrals WHERE referrer_id = ? AND referred_id = ?',
      [newUserId, referrer.id]
    );
    if (circular.length) throw new Error('CIRCULAR_REFERRAL_BLOCKED');

    // Store PENDING — coins only awarded when referred user PAYS
    query(
      'INSERT OR IGNORE INTO referrals (id, referrer_id, referred_id, status) VALUES (?, ?, ?, ?)',
      [uuidv4(), referrer.id, newUserId, 'pending']
    );

    return { referrerId: referrer.id };
  }

  // Called ONLY after referred user pays
  static async activateReferral(newUserId) {
    const refs = query(`
      SELECT r.*, u.tier_num FROM referrals r
      JOIN users u ON r.referrer_id = u.id
      WHERE r.referred_id = ? AND r.status = 'pending'
    `, [newUserId]);

    if (!refs.length) return;
    const ref = refs[0];

    const referrerCoins = 50 * ref.tier_num; // More coins for higher tiers
    const referredCoins = 50;

    query('UPDATE users SET coins = coins + ?, referral_count = referral_count + 1 WHERE id = ?', [referrerCoins, ref.referrer_id]);
    query('UPDATE users SET coins = coins + ? WHERE id = ?', [referredCoins, newUserId]);
    query("UPDATE referrals SET status = 'active' WHERE referred_id = ?", [newUserId]);

    query('INSERT INTO coin_transactions (id, user_id, amount, type, description) VALUES (?, ?, ?, ?, ?)',
      [uuidv4(), ref.referrer_id, referrerCoins, 'referral', 'Referral bonus']);
    query('INSERT INTO coin_transactions (id, user_id, amount, type, description) VALUES (?, ?, ?, ?, ?)',
      [uuidv4(), newUserId, referredCoins, 'referral', 'Welcome referral bonus']);
  }

  static logFraud(userId, event, details) {
    query('INSERT INTO security_logs (id, user_id, event, details) VALUES (?, ?, ?, ?)',
      [uuidv4(), userId, event, JSON.stringify(details)]);
  }
}

module.exports = ReferralService;
