// test.js — Live proof of all security features
process.env.OTP_SALT = 'grow31salt';
process.env.JWT_ACCESS_SECRET = 'access_secret_64chars_in_prod';
process.env.JWT_REFRESH_SECRET = 'refresh_secret_64chars_in_prod';
process.env.ADMIN_SECRET_KEY = 'admin_key_change_in_prod';

const http = require('http');

function post(path, body, token) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const opts = {
      hostname: 'localhost', port: 3001, path,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      }
    };
    const req = http.request(opts, res => {
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(body) }); }
        catch { resolve({ status: res.statusCode, body }); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function get(path, token) {
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: 'localhost', port: 3001, path,
      method: 'GET',
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    };
    const req = http.request(opts, res => {
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(body) }); }
        catch { resolve({ status: res.statusCode, body }); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

const PASS = '✅ PASS';
const FAIL = '❌ FAIL';

async function runTests() {
  console.log('\n══════════════════════════════════════════════');
  console.log('   🔐 GROW31 SECURITY PROOF — LIVE TESTS');
  console.log('══════════════════════════════════════════════\n');

  let token, demoOTP;

  // ── TEST 1: OTP Generation ────────────────────────────
  console.log('▶ TEST 1: Send OTP (cryptographic, server-side)');
  const otpRes = await post('/api/auth/send-otp', { phone: '9876543210' });
  demoOTP = otpRes.body._demo_otp;
  const t1 = otpRes.status === 200 && demoOTP && demoOTP.length === 6;
  console.log(`   ${t1 ? PASS : FAIL} Status: ${otpRes.status}, OTP sent: ${demoOTP || 'N/A'}`);
  if (t1) console.log(`   ℹ  In production: OTP goes to phone only, _demo_otp field removed`);

  // ── TEST 2: OTP Cooldown ──────────────────────────────
  console.log('\n▶ TEST 2: OTP Cooldown (60s — cannot spam SMS)');
  const cooldownRes = await post('/api/auth/send-otp', { phone: '9876543210' });
  const t2 = cooldownRes.status === 429 && cooldownRes.body.error === 'OTP_COOLDOWN';
  console.log(`   ${t2 ? PASS : FAIL} Status: ${cooldownRes.status} → ${cooldownRes.body.error} (wait ${cooldownRes.body.wait}s)`);

  // ── TEST 3: Wrong OTP ─────────────────────────────────
  console.log('\n▶ TEST 3: Wrong OTP rejected (cannot guess)');
  const wrongOTP = await post('/api/auth/verify-otp', { phone: '9876543210', otp: '000000', username: 'TestUser' });
  const t3 = wrongOTP.status === 400 && wrongOTP.body.error === 'OTP_INVALID';
  console.log(`   ${t3 ? PASS : FAIL} Status: ${wrongOTP.status} → ${wrongOTP.body.error}, ${wrongOTP.body.attemptsRemaining} attempts left`);

  // ── TEST 4: Correct OTP + Registration ───────────────
  console.log('\n▶ TEST 4: Correct OTP → register + issue JWT');
  const loginRes = await post('/api/auth/verify-otp', { phone: '9876543210', otp: demoOTP, username: 'Rahul_Grow31' });
  token = loginRes.body.accessToken;
  const t4 = loginRes.status === 200 && token && loginRes.body.user?.username === 'Rahul_Grow31';
  console.log(`   ${t4 ? PASS : FAIL} Status: ${loginRes.status}, JWT issued: ${token ? 'YES' : 'NO'}`);
  console.log(`   ℹ  User: ${loginRes.body.user?.username}, Coins: ${loginRes.body.user?.coins}, Paid: ${loginRes.body.user?.hasPaid}`);

  // ── TEST 5: Protected route without token ─────────────
  console.log('\n▶ TEST 5: Access protected route WITHOUT token (must fail)');
  const noToken = await get('/api/user/profile');
  const t5 = noToken.status === 401 && noToken.body.error === 'NO_TOKEN';
  console.log(`   ${t5 ? PASS : FAIL} Status: ${noToken.status} → ${noToken.body.error}`);

  // ── TEST 6: Protected route WITH valid JWT ────────────
  console.log('\n▶ TEST 6: Access profile WITH valid JWT (must work)');
  const withToken = await get('/api/user/profile', token);
  const t6 = withToken.status === 200 && withToken.body.username === 'Rahul_Grow31';
  console.log(`   ${t6 ? PASS : FAIL} Status: ${withToken.status}, User: ${withToken.body.username}`);

  // ── TEST 7: Task complete without paying ──────────────
  console.log('\n▶ TEST 7: Complete task WITHOUT paying (must be blocked)');
  const noPayTask = await post('/api/tasks/complete', { taskKey: 'task_walk_20', day: 1 }, token);
  const t7 = noPayTask.status === 403 && noPayTask.body.error === 'PAYMENT_REQUIRED';
  console.log(`   ${t7 ? PASS : FAIL} Status: ${noPayTask.status} → ${noPayTask.body.error}`);
  console.log(`   ℹ  Cannot self-award coins without verified payment`);

  // ── TEST 8: Simulate paid user + task timing ──────────
  console.log('\n▶ TEST 8: Force-mark user as paid, try timed task without timer');
  // Manually set paid in DB for test
  const { query } = require('./config/db');
  query("UPDATE users SET has_paid = 1, spin_tickets = 3 WHERE phone = '9876543210'");

  const noTimer = await post('/api/tasks/complete', { taskKey: 'task_run_5k', day: 1 }, token);
  const t8 = noTimer.status === 400 && noTimer.body.error === 'TIMER_NOT_STARTED';
  console.log(`   ${t8 ? PASS : FAIL} Status: ${noTimer.status} → ${noTimer.body.error}`);
  console.log(`   ℹ  Hard tasks require server timer to be started first`);

  // ── TEST 9: Easy task (self-report) works for paid user
  console.log('\n▶ TEST 9: Easy self-report task works for paid user');
  const easyTask = await post('/api/tasks/complete', { taskKey: 'task_walk_20', day: 1 }, token);
  const t9 = easyTask.status === 200 && easyTask.body.coinsAwarded === 5;
  console.log(`   ${t9 ? PASS : FAIL} Status: ${easyTask.status}, Coins awarded: ${easyTask.body.coinsAwarded}, New balance: ${easyTask.body.newBalance}`);

  // ── TEST 10: Double completion blocked ────────────────
  console.log('\n▶ TEST 10: Double task completion blocked (idempotency)');
  const doubleTask = await post('/api/tasks/complete', { taskKey: 'task_walk_20', day: 1 }, token);
  const t10 = doubleTask.status === 409 && doubleTask.body.error === 'ALREADY_COMPLETED';
  console.log(`   ${t10 ? PASS : FAIL} Status: ${doubleTask.status} → ${doubleTask.body.error}`);

  // ── TEST 11: Server-side spin ─────────────────────────
  console.log('\n▶ TEST 11: Spin wheel — server picks outcome (not browser)');
  const spin = await post('/api/spin', { spinType: 'ticket' }, token);
  const t11 = spin.status === 200 && spin.body.prize && spin.body.finalAngle !== undefined;
  console.log(`   ${t11 ? PASS : FAIL} Status: ${spin.status}`);
  if (t11) {
    console.log(`   ℹ  Server chose: ${spin.body.prize.label} (${spin.body.prize.coins} coins)`);
    console.log(`   ℹ  Frontend must animate to angle: ${spin.body.finalAngle.toFixed(4)} rad — no manipulation possible`);
    console.log(`   ℹ  New balance: ${spin.body.newBalance} coins`);
  }

  // ── TEST 12: Spin exhaustion ──────────────────────────
  console.log('\n▶ TEST 12: Spin with no tickets (must fail)');
  // Drain remaining tickets
  await post('/api/spin', { spinType: 'ticket' }, token);
  await post('/api/spin', { spinType: 'ticket' }, token);
  const noTicket = await post('/api/spin', { spinType: 'ticket' }, token);
  const t12 = noTicket.status === 400 && noTicket.body.error === 'NO_TICKETS';
  console.log(`   ${t12 ? PASS : FAIL} Status: ${noTicket.status} → ${noTicket.body.error}`);

  // ── TEST 13: Admin without key ────────────────────────
  console.log('\n▶ TEST 13: Admin panel without secret key (must be blocked)');
  const noAdmin = await get('/api/admin/security-logs');
  const t13 = noAdmin.status === 403 && noAdmin.body.error === 'FORBIDDEN';
  console.log(`   ${t13 ? PASS : FAIL} Status: ${noAdmin.status} → ${noAdmin.body.error}`);

  // ── TEST 14: Invalid phone ────────────────────────────
  console.log('\n▶ TEST 14: Invalid phone number validation');
  const badPhone = await post('/api/auth/send-otp', { phone: 'hack123' });
  const t14 = badPhone.status === 400 && badPhone.body.error === 'INVALID_PHONE';
  console.log(`   ${t14 ? PASS : FAIL} Status: ${badPhone.status} → ${badPhone.body.error}`);

  // ── SUMMARY ───────────────────────────────────────────
  const tests = [t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14];
  const passed = tests.filter(Boolean).length;
  console.log('\n══════════════════════════════════════════════');
  console.log(`   RESULT: ${passed}/${tests.length} tests passed`);
  console.log('══════════════════════════════════════════════\n');
  process.exit(passed === tests.length ? 0 : 1);
}

// Wait for server then run
setTimeout(runTests, 1000);
