// routes/tasks.js
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const AuthService = require('../middleware/auth');
const { query } = require('../config/db');

// Task timer store (use Redis in prod)
const taskTimers = new Map();

const TASK_DIFFICULTIES = {
  easy:   { reward: 5,  minSeconds: null },
  medium: { reward: 10, minSeconds: 30   },
  hard:   { reward: 20, minSeconds: 60   },
};

// POST /api/tasks/start-timer — must call this BEFORE completing timed tasks
router.post('/start-timer', AuthService.requireAuth, (req, res) => {
  const { taskKey, day } = req.body;
  const key = `${req.userId}:${taskKey}:${day}`;
  taskTimers.set(key, Date.now());
  res.json({ started: true, serverTime: Date.now() });
});

// POST /api/tasks/complete
router.post('/complete', AuthService.requireAuth, async (req, res) => {
  try {
    const { taskKey, day } = req.body;
    const userId = req.userId;

    if (!taskKey || !day) return res.status(400).json({ error: 'MISSING_FIELDS' });

    // 1. Find task in server-side task bank (answers NOT in frontend)
    const task = SERVER_TASK_BANK.find(t => t.key === taskKey);
    if (!task) return res.status(400).json({ error: 'INVALID_TASK' });

    // 2. User must have paid and be on the correct day
    const users = query('SELECT * FROM users WHERE id = ? AND has_paid = 1', [userId]);
    if (!users.length) return res.status(403).json({ error: 'PAYMENT_REQUIRED', message: 'Only paid users can complete tasks' });

    const u = users[0];

    // 3. Prevent future-day task completion
    if (day > u.current_day) {
      return res.status(400).json({ error: 'TASK_NOT_UNLOCKED', message: `You are on Day ${u.current_day}, not Day ${day}` });
    }

    // 4. Idempotency — prevent double completion
    const existing = query(
      'SELECT id FROM task_completions WHERE user_id = ? AND task_key = ? AND day = ?',
      [userId, taskKey, day]
    );
    if (existing.length) return res.status(409).json({ error: 'ALREADY_COMPLETED', message: 'Task already done today' });

    // 5. Verify by difficulty
    const difficulty = task.difficulty || 'easy';
    const diffConfig = TASK_DIFFICULTIES[difficulty];

    if (diffConfig.minSeconds) {
      // Timed task: verify server-side timer was started
      const timerKey = `${userId}:${taskKey}:${day}`;
      const timerStart = taskTimers.get(timerKey);

      if (!timerStart) {
        return res.status(400).json({
          error: 'TIMER_NOT_STARTED',
          message: 'You must start the task timer before completing it'
        });
      }

      const elapsedSeconds = (Date.now() - timerStart) / 1000;
      if (elapsedSeconds < diffConfig.minSeconds) {
        return res.status(400).json({
          error: 'INSUFFICIENT_TIME',
          required: diffConfig.minSeconds,
          elapsed: Math.floor(elapsedSeconds),
          message: `You need ${diffConfig.minSeconds - Math.floor(elapsedSeconds)} more seconds`
        });
      }

      taskTimers.delete(timerKey); // Cleanup
    }

    // 6. Award coins IN DATABASE
    const reward = diffConfig.reward;

    query(
      'INSERT INTO task_completions (id, user_id, task_key, day, reward, verification_method) VALUES (?, ?, ?, ?, ?, ?)',
      [uuidv4(), userId, taskKey, day, reward, task.verificationMethod || 'self_report']
    );
    query('UPDATE users SET coins = coins + ?, updated_at = datetime("now") WHERE id = ?', [reward, userId]);
    query(
      'INSERT INTO coin_transactions (id, user_id, amount, type, description) VALUES (?, ?, ?, ?, ?)',
      [uuidv4(), userId, reward, 'task', `Task: ${task.title} (Day ${day})`]
    );

    // Check all-tasks-done bonus
    const totalTasks = SERVER_TASK_BANK.length;
    const completedToday = query(
      'SELECT COUNT(*) as cnt FROM task_completions WHERE user_id = ? AND day = ?',
      [userId, day]
    );
    const allDoneBonus = completedToday[0]?.cnt >= totalTasks ? 30 : 0;
    if (allDoneBonus > 0) {
      query('UPDATE users SET coins = coins + ? WHERE id = ?', [allDoneBonus, userId]);
      query('INSERT INTO coin_transactions (id, user_id, amount, type, description) VALUES (?, ?, ?, ?, ?)',
        [uuidv4(), userId, allDoneBonus, 'bonus', 'All tasks completed bonus']);
    }

    const updatedUser = query('SELECT coins FROM users WHERE id = ?', [userId]);

    res.json({
      success: true,
      coinsAwarded: reward,
      allDoneBonus,
      newBalance: updatedUser[0].coins
    });

  } catch (e) {
    console.error('Task complete error:', e);
    res.status(500).json({ error: 'SERVER_ERROR' });
  }
});

// GET /api/tasks/progress
router.get('/progress', AuthService.requireAuth, (req, res) => {
  const { day } = req.query;
  const completions = query(
    'SELECT task_key, completed_at FROM task_completions WHERE user_id = ? AND day = ?',
    [req.userId, day || 1]
  );
  res.json({ completions });
});

// Server-side task bank — answers/logic NOT exposed to frontend
const SERVER_TASK_BANK = [
  { key: 'task_walk_20',        title: 'Morning Walk (20 mins)',          difficulty: 'easy',   verificationMethod: 'self_report' },
  { key: 'task_run_5k',         title: 'Run or Jog 5km',                  difficulty: 'hard',   verificationMethod: 'timed'       },
  { key: 'task_water_8',        title: 'Drink 8 Glasses of Water',        difficulty: 'easy',   verificationMethod: 'self_report' },
  { key: 'task_sleep_10',       title: 'Sleep by 10:30 PM',               difficulty: 'medium', verificationMethod: 'timed'       },
  { key: 'task_no_junk',        title: 'Eat Zero Junk Food Today',        difficulty: 'hard',   verificationMethod: 'timed'       },
  { key: 'task_yoga',           title: '15-Min Yoga or Stretching',       difficulty: 'medium', verificationMethod: 'timed'       },
  { key: 'task_exercise_30',    title: 'Exercise for 30 Minutes',         difficulty: 'hard',   verificationMethod: 'timed'       },
  { key: 'task_no_sugar',       title: 'Avoid Sugar for Entire Day',      difficulty: 'hard',   verificationMethod: 'timed'       },
  { key: 'task_steps_7k',       title: 'Complete 7,000 Steps',            difficulty: 'medium', verificationMethod: 'self_report' },
  { key: 'task_meditation',     title: '15-Min Meditation',               difficulty: 'easy',   verificationMethod: 'self_report' },
  { key: 'task_read_20',        title: 'Read 20 Pages of a Book',         difficulty: 'medium', verificationMethod: 'timed'       },
  { key: 'task_podcast',        title: 'Listen to a 20-Min Podcast',      difficulty: 'easy',   verificationMethod: 'self_report' },
  { key: 'task_learn_skill',    title: 'Learn 1 New Skill Online (30 min)',difficulty:'hard',   verificationMethod: 'timed'       },
  { key: 'task_news',           title: "Read Today's Business News",       difficulty: 'easy',   verificationMethod: 'self_report' },
  { key: 'task_journal',        title: 'Journal: Write 3 Goals',          difficulty: 'easy',   verificationMethod: 'self_report' },
  { key: 'task_no_social_2h',   title: 'No Social Media for 2 Hours',     difficulty: 'hard',   verificationMethod: 'timed'       },
  { key: 'task_deep_work',      title: 'Do 90-Min Deep Work Session',     difficulty: 'hard',   verificationMethod: 'timed'       },
  { key: 'task_gratitude',      title: 'Write 5 Things You\'re Grateful For',difficulty:'easy', verificationMethod: 'self_report' },
  { key: 'task_share_story',    title: 'Share Grow31 Progress on Story',  difficulty: 'medium', verificationMethod: 'screenshot_upload'},
  { key: 'task_follow_ig',      title: 'Follow Grow31 on Instagram',      difficulty: 'easy',   verificationMethod: 'self_report' },
];

module.exports = router;
