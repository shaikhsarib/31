// middleware/auth.js
const jwt = require('jsonwebtoken');
const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');

const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '30d';

// In-memory refresh token store (use Redis in prod)
const refreshTokenStore = new Map();

class AuthService {

  static generateTokens(userId, phone) {
    const accessToken = jwt.sign(
      { userId, phone, type: 'access' },
      process.env.JWT_ACCESS_SECRET || 'dev_access_secret_change_in_prod',
      { expiresIn: ACCESS_TOKEN_EXPIRY }
    );
    const refreshToken = jwt.sign(
      { userId, phone, type: 'refresh', jti: uuidv4() },
      process.env.JWT_REFRESH_SECRET || 'dev_refresh_secret_change_in_prod',
      { expiresIn: REFRESH_TOKEN_EXPIRY }
    );
    // Store hashed refresh token
    const hash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    refreshTokenStore.set(`${userId}:${hash}`, { userId, phone, createdAt: Date.now() });

    return { accessToken, refreshToken };
  }

  static revokeAllUserTokens(userId) {
    for (const key of refreshTokenStore.keys()) {
      if (key.startsWith(`${userId}:`)) refreshTokenStore.delete(key);
    }
  }

  // Middleware: verify JWT on every protected route
  static requireAuth(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'NO_TOKEN', message: 'Authorization header required' });
    }
    try {
      const token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET || 'dev_access_secret_change_in_prod');
      if (decoded.type !== 'access') throw new Error('WRONG_TOKEN_TYPE');

      // Check if user is banned
      const users = query('SELECT is_banned, ban_reason FROM users WHERE id = ?', [decoded.userId]);
      if (users[0]?.is_banned) {
        return res.status(403).json({ error: 'ACCOUNT_BANNED', reason: users[0].ban_reason });
      }

      req.userId = decoded.userId;
      req.userPhone = decoded.phone;
      next();
    } catch (e) {
      if (e.name === 'TokenExpiredError') {
        return res.status(401).json({ error: 'TOKEN_EXPIRED', message: 'Refresh your token' });
      }
      return res.status(401).json({ error: 'INVALID_TOKEN' });
    }
  }

  // Admin-only middleware
  static requireAdmin(req, res, next) {
    const adminKey = req.headers['x-admin-key'];
    if (!adminKey || adminKey !== process.env.ADMIN_SECRET_KEY) {
      // Log unauthorized admin attempt
      query(
        'INSERT INTO security_logs (id, user_id, event, ip_address) VALUES (?, ?, ?, ?)',
        [require('uuid').v4(), null, 'UNAUTHORIZED_ADMIN_ACCESS', req.ip]
      );
      return res.status(403).json({ error: 'FORBIDDEN' });
    }
    next();
  }
}

module.exports = AuthService;
