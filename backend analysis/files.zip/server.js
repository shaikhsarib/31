// server.js — Grow31 Secure Backend


const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const { initDB } = require('./config/db');
const authRoutes = require('./routes/auth');
const taskRoutes = require('./routes/tasks');
const AuthService = require('./middleware/auth');
const SpinService = require('./services/spinService');
const { query } = require('./config/db');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Security Headers ──────────────────────────────────
app.use(helmet());
app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", "https://checkout.razorpay.com"],
  }
}));

// ── CORS ──────────────────────────────────────────────
const allowedOrigins = (process.env.FRONTEND_URL || 'http://localhost:8080').split(',');
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes(origin) || process.env.NODE_ENV !== 'production') {
      cb(null, true);
    } else {
      cb(new Error('CORS_BLOCKED'));
    }
  },
  methods: ['GET', 'POST', 'PUT'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-device-id', 'x-admin-key'],
}));

// ── Body + Size Limit ─────────────────────────────────
app.use(express.json({ limit: '10kb' }));

// ── Global Rate Limit ─────────────────────────────────
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: 'TOO_MANY_REQUESTS' }
}));

// ── Auth Rate Limit (stricter) ────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  keyGenerator: (req) => req.body?.phone || req.ip,
  message: { error: 'TOO_MANY_AUTH_ATTEMPTS' }
});

// ── Routes ────────────────────────────────────────────
app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/tasks', taskRoutes);

// ── Spin Wheel (Server-Side Outcome) ─────────────────
app.post('/api/spin', AuthService.requireAuth, async (req, res) => {
  try {
    const { spinType } = req.body;
    const result = await SpinService.spin(req.userId, spinType || 'ticket');
    res.json(result);
  } catch (e) {
    const errorMap = {
      'SPIN_IN_PROGRESS': [429, 'Spin already in progress'],
      'USER_NOT_FOUND': [404, 'User not found'],
      'PAYMENT_REQUIRED': [403, 'Payment required to spin'],
      'NO_TICKETS': [400, 'No spin tickets available'],
    };
    const [status, message] = errorMap[e.message] || [500, 'Server error'];
    res.status(status).json({ error: e.message, message });
  }
});

// ── User Profile ──────────────────────────────────────
app.get('/api/user/profile', AuthService.requireAuth, (req, res) => {
  const users = query('SELECT * FROM users WHERE id = ?', [req.userId]);
  if (!users.length) return res.status(404).json({ error: 'NOT_FOUND' });
  const u = users[0];
  // Never return raw phone or sensitive fields to client
  res.json({
    id: u.id,
    username: u.username,
    coins: u.coins,
    hasPaid: !!u.has_paid,
    tierNum: u.tier_num,
    currentDay: u.current_day,
    spinTickets: u.spin_tickets,
    referralCount: u.referral_count,
    refCode: u.ref_code,
    streak: u.streak,
  });
});

// ── Coin Transaction History ──────────────────────────
app.get('/api/user/transactions', AuthService.requireAuth, (req, res) => {
  const txns = query(
    'SELECT amount, type, description, created_at FROM coin_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
    [req.userId]
  );
  res.json({ transactions: txns });
});

// ── Admin: View Security Logs ─────────────────────────
app.get('/api/admin/security-logs', AuthService.requireAdmin, (req, res) => {
  const logs = query('SELECT * FROM security_logs ORDER BY created_at DESC LIMIT 100');
  res.json({ logs });
});

// ── Admin: Ban User ───────────────────────────────────
app.post('/api/admin/ban', AuthService.requireAdmin, (req, res) => {
  const { userId, reason } = req.body;
  if (!userId) return res.status(400).json({ error: 'USER_ID_REQUIRED' });
  query('UPDATE users SET is_banned = 1, ban_reason = ? WHERE id = ?', [reason || 'Banned by admin', userId]);
  query('INSERT INTO security_logs (id, user_id, event, details) VALUES (?, ?, ?, ?)',
    [uuidv4(), userId, 'USER_BANNED', JSON.stringify({ reason, bannedBy: 'admin' })]);
  res.json({ success: true });
});

// ── Health Check ──────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── 404 Handler ───────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'ENDPOINT_NOT_FOUND' });
});

// ── Error Handler ─────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'INTERNAL_SERVER_ERROR' });
});

// ── Start ─────────────────────────────────────────────
initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`\n🔐 Grow31 Secure Backend running on http://localhost:${PORT}`);
    console.log(`   → OTP: cryptographically secure, hashed, 5-min TTL`);
    console.log(`   → JWT: 15-min access tokens + 30-day refresh tokens`);
    console.log(`   → Tasks: server-authoritative, no self-reporting`);
    console.log(`   → Spin: server picks outcome, browser gets angle`);
    console.log(`   → Referral: device + IP fraud detection\n`);
  });
}).catch(err => {
  console.error('Failed to initialize DB:', err);
  process.exit(1);
});

module.exports = app;
