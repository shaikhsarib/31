// routes/auth.js
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const OTPService = require('../services/otpService');
const AuthService = require('../middleware/auth');
const { query } = require('../config/db');
const ReferralService = require('../services/referralService');

// Helpers
function generateRefCode(username, phone) {
  return `Grow31/${username.replace(/\s/g,'')}-${phone.slice(-4)}`;
}

// POST /api/auth/send-otp
router.post('/send-otp', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone || !/^\d{10}$/.test(phone)) {
      return res.status(400).json({ error: 'INVALID_PHONE', message: 'Enter a valid 10-digit phone number' });
    }
    const result = await OTPService.sendOTP(phone);
    res.json(result);
  } catch (e) {
    if (e.message.startsWith('OTP_COOLDOWN:')) {
      return res.status(429).json({ error: 'OTP_COOLDOWN', wait: parseInt(e.message.split(':')[1]) });
    }
    if (e.message === 'TOO_MANY_OTP_REQUESTS') {
      return res.status(429).json({ error: 'TOO_MANY_OTP_REQUESTS', message: 'Daily OTP limit reached' });
    }
    console.error('send-otp error:', e);
    res.status(500).json({ error: 'SERVER_ERROR' });
  }
});

// POST /api/auth/verify-otp  (login or register)
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, otp, username, referralCode } = req.body;
    if (!phone || !otp) return res.status(400).json({ error: 'MISSING_FIELDS' });

    // Verify OTP — throws on failure
    await OTPService.verifyOTP(phone, otp);

    // Check if user exists
    let users = query('SELECT * FROM users WHERE phone = ?', [phone]);
    let user = users[0];
    let isNewUser = false;

    if (!user) {
      // New registration
      if (!username || username.trim().length < 2) {
        return res.status(400).json({ error: 'USERNAME_REQUIRED', message: 'Username required for new accounts' });
      }
      const sanitizedUsername = username.replace(/[^a-zA-Z0-9_\s]/g, '').trim().slice(0, 30);
      const userId = uuidv4();
      const refCode = generateRefCode(sanitizedUsername, phone);

      query(`
        INSERT INTO users (id, phone, username, ref_code, registration_ip, device_fingerprint)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [userId, phone, sanitizedUsername, refCode, req.ip, req.headers['x-device-id'] || null]);

      user = query('SELECT * FROM users WHERE id = ?', [userId])[0];
      isNewUser = true;

      // Apply referral if provided
      if (referralCode) {
        try {
          await ReferralService.applyReferral(
            userId, phone, referralCode,
            req.ip, req.headers['x-device-id']
          );
        } catch (e) {
          console.log('Referral rejected:', e.message); // Don't fail login for bad referral
        }
      }
    }

    const tokens = AuthService.generateTokens(user.id, user.phone);

    res.json({
      success: true,
      isNewUser,
      user: {
        id: user.id,
        phone: user.phone,
        username: user.username,
        coins: user.coins,
        hasPaid: !!user.has_paid,
        tierNum: user.tier_num,
        currentDay: user.current_day,
        spinTickets: user.spin_tickets,
        referralCount: user.referral_count,
        refCode: user.ref_code,
      },
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    });
  } catch (e) {
    if (e.message === 'OTP_NOT_FOUND_OR_EXPIRED') return res.status(400).json({ error: 'OTP_EXPIRED', message: 'OTP expired. Request a new one.' });
    if (e.message === 'OTP_EXPIRED') return res.status(400).json({ error: 'OTP_EXPIRED' });
    if (e.message === 'OTP_MAX_ATTEMPTS_EXCEEDED') return res.status(429).json({ error: 'OTP_LOCKED', message: 'Too many wrong attempts. Request a new OTP.' });
    if (e.message.startsWith('OTP_INVALID:')) {
      const remaining = e.message.split(':')[1];
      return res.status(400).json({ error: 'OTP_INVALID', attemptsRemaining: parseInt(remaining) });
    }
    console.error('verify-otp error:', e);
    res.status(500).json({ error: 'SERVER_ERROR' });
  }
});

// GET /api/auth/me — get current user (requires auth)
router.get('/me', AuthService.requireAuth, (req, res) => {
  const users = query('SELECT * FROM users WHERE id = ?', [req.userId]);
  if (!users.length) return res.status(404).json({ error: 'USER_NOT_FOUND' });
  const u = users[0];
  res.json({
    id: u.id,
    phone: u.phone,
    username: u.username,
    coins: u.coins,
    hasPaid: !!u.has_paid,
    tierNum: u.tier_num,
    currentDay: u.current_day,
    spinTickets: u.spin_tickets,
    referralCount: u.referral_count,
    refCode: u.ref_code,
    streak: u.streak,
  });
});

module.exports = router;
